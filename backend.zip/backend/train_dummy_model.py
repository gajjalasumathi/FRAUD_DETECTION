import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import joblib
import os

# Dummy training data to encompass the fraud types mentioned in requirements
data = {
    "message": [
        "Congratulations! You won the microsoft lottery. Send money to claim.",
        "Your account is blocked. Click the link to verify.",
        "Please pay the registration fee to secure your job application.",
        "Send your UPI pin to receive the cashback of Rs 5000.",
        "Hey, are we still meeting for lunch today?",
        "Can you send me the latest project report?",
        "Your OTP is 1234. Do not share this with anyone."
    ],
    "label": [
        "Lottery Scam",
        "Phishing",
        "Job Scam",
        "UPI Fraud",
        "Safe",
        "Safe",
        "Safe"
    ]
}

df = pd.DataFrame(data)

# Create a pipeline with TF-IDF and Logistic Regression
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('clf', LogisticRegression())  # LogisticRegression supports predict_proba naturally
])

pipeline.fit(df['message'], df['label'])

os.makedirs('model', exist_ok=True)
joblib.dump(pipeline, 'model/scam_model.pkl')
print("Dummy model saved successfully to model/scam_model.pkl")
