import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import joblib
import os
import sys

# Add backend dir to path so we can import database
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from database.db import init_db
from pymongo import MongoClient

# Make sure we import db variable correctly depending on how it's initialized
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")

def retrain():
    # 1. Expanded Accurate Base Dataset
    base_data = {
        "message": [
            "Congratulations! You won the microsoft lottery. Send money to claim.",
            "Your account is blocked. Click the link to verify.",
            "Please pay the registration fee to secure your job application.",
            "Send your UPI pin to receive the cashback of Rs 5000.",
            "Hey, are we still meeting for lunch today?",
            "Can you send me the latest project report?",
            "Your OTP is 1234. Do not share this with anyone.",
            "URGENT: Your bank account will be suspended. Update KYC immediately via this link.",
            "You have been selected for a part time remote job. Earn Rs 5000 daily. Pay Rs 999 as joining kit fee.",
            "Dear customer, your electricity bill is pending. Power will be cut by 9 PM. Call this number to pay.",
            "Scan this QR code to receive your refund of Rs 2000.",
            "Congratulations you have won a new iPhone! Click here and pay shipping to get it.",
            "Let's schedule a meeting for tomorrow at 10 AM regarding the upcoming sprint.",
            "Please find attached the invoice for last month's services.",
            "Are you coming to the family dinner on Sunday?",
            "Happy birthday! Wishing you a great year ahead.",
            "To complete your delivery, please pay the small customs fee of $2.",
            "Your Netflix subscription has expired. Update your payment details here to avoid cancellation.",
            "I will call you back in 10 minutes.",
            "Just checking in, how are you doing?",
            "Win a free gift card by filling out this survey! Enter your credit card to verify.",
            "Click the link to get your free airline tickets now!",
            "Can we reschedule our call to 3 PM?",
            "Don't forget to buy milk on your way home."
        ],
        "label": [
            "Lottery Scam", "Phishing", "Job Scam", "UPI Fraud", "Safe", "Safe", "Safe",
            "Phishing", "Job Scam", "Phishing", "UPI Fraud", "Lottery Scam", "Safe",
            "Safe", "Safe", "Safe", "Phishing", "Phishing", "Safe", "Safe",
            "Phishing", "Lottery Scam", "Safe", "Safe"
        ]
    }
    
    df_base = pd.DataFrame(base_data)
    
    # 2. Fetch User Feedback from MongoDB
    try:
        client = MongoClient(MONGO_URI)
        db = client["fraud_detection"]
        feedback_cursor = db.user_feedback.find({}, {"_id": 0, "message": 1, "label": 1})
        feedback_list = list(feedback_cursor)
    except Exception as e:
        print(f"Error fetching from MongoDB: {e}. Attempting to use local JSON fallback.")
        
    if not feedback_list:
        try:
            fallback_path = os.path.join(os.path.dirname(__file__), 'database', 'fallback_feedback.json')
            if os.path.exists(fallback_path):
                import json
                with open(fallback_path, 'r') as f:
                    logs = json.load(f)
                    
                for log in logs:
                    if "label" in log and "message" in log:
                         feedback_list.append({"message": log["message"], "label": log["label"]})
        except Exception as e:
            print(f"Error reading JSON fallback: {e}")
        
    if feedback_list:
        df_feedback = pd.DataFrame(feedback_list)
        # Combine base data and user feedback
        df_train = pd.concat([df_base, df_feedback], ignore_index=True)
        print(f"Added {len(df_feedback)} user reported messages to the training set!")
    else:
        df_train = df_base
        print("No user feedback found in database yet. Training on base data only.")

    # 3. Train the Model
    # Using stop_words='english' makes the model focus on important words instead of 'the', 'is', 'at'
    # class_weight='balanced' helps giving appropriate weights to all scam types evenly
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(stop_words='english', max_features=5000)),
        ('clf', LogisticRegression(class_weight='balanced'))  
    ])
    
    print(f"Training model with dataset size: {len(df_train)} messages")
    pipeline.fit(df_train['message'], df_train['label'])
    
    # 4. Save the Model
    os.makedirs('model', exist_ok=True)
    joblib.dump(pipeline, 'model/scam_model.pkl')
    print("Model retrained successfully and saved to model/scam_model.pkl")

if __name__ == "__main__":
    retrain()
