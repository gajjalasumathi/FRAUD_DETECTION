import joblib
import os
import numpy as np

# Load model once at module initialization
MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'model', 'scam_model.pkl')
model = None
vectorizer = None

def load_model():
    global model, vectorizer
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")
    
    pipeline = joblib.load(MODEL_PATH)
    # The pipeline is assumed to have a 'tfidf' step and 'clf' step for Logistic Regression
    vectorizer = pipeline.named_steps['tfidf']
    model = pipeline.named_steps['clf']
    print("Model loaded successfully.")

def get_prevention_tips(fraud_type):
    tips_map = {
        "UPI Fraud": ["Do not share OTP", "Never click on unverified payment links", "Verify the receiver's identity before transferring money"],
        "Job Scam": ["Never pay registration fee", "Research the company thoroughly", "Legitimate employers won't ask for your bank details upfront"],
        "Lottery Scam": ["Government lotteries do not ask for money to claim a prize", "If you didn't enter a lottery, you didn't win one", "Ignore unsolicited messages about winning massive amounts of money"],
        "Phishing": ["Avoid clicking unknown links", "Check the sender's email address carefully", "Do not provide sensitive information on login pages you reached via a random link"],
        "Safe": ["Always stay vigilant online", "Keep your software updated"]
    }
    
    # Return generic tips if the exact type isn't found
    return tips_map.get(fraud_type, ["Be careful when sharing personal information online", "Verify the sender before taking action"])

def extract_highlight_words(text, num_words=5):
    if vectorizer is None or model is None:
        return []
    
    # Transform text to tf-idf vector
    tfidf_matrix = vectorizer.transform([text])
    feature_names = vectorizer.get_feature_names_out()
    
    # Get the indices of the non-zero elements
    nonzero_indices = tfidf_matrix.nonzero()[1]
    
    # Get the tf-idf scores for these non-zero elements
    tfidf_scores = tfidf_matrix[0, nonzero_indices].toarray()[0]
    
    # Sort indices by score
    sorted_indices = nonzero_indices[np.argsort(tfidf_scores)[::-1]]
    
    # Select top N words
    top_indices = sorted_indices[:num_words]
    highlight_words = [feature_names[i] for i in top_indices]
    
    return highlight_words

def predict_fraud(message):
    if model is None or vectorizer is None:
        load_model()
        
    # Get prediction
    features = vectorizer.transform([message])
    prediction_idx = model.predict(features)[0]
    
    # Attempt to get probability
    # Determine risk level
    try:
        probabilities = model.predict_proba(features)[0]
        # Depending on how the model is trained, we need the max probability or the probability of 'fraud'
        # For our multi-class dummy model, we just take the probability of the predicted class
        
        predicted_class_idx = np.where(model.classes_ == prediction_idx)[0][0]
        probability = probabilities[predicted_class_idx] * 100
        
        fraud_type = prediction_idx
        
        # Override probability for 'Safe' to represent 'risk logic'
        if fraud_type == "Safe":
             # Safe predictions usually mean high probability of being safe, therefore low risk probability
             # We can invert this or map it
             risk_prob = (1 - (probability/100)) * 100 
             
             # If risk_prob is still low, keep it
             probability = risk_prob
        else:
            # If it's a fraud type, the probability is the risk probability
            pass
            
    except Exception as e:
         # Fallback if probability not available
         probability = 85 if prediction_idx != "Safe" else 10
         fraud_type = prediction_idx

    
    # Ensure probability is between 0-100
    probability = max(0, min(100, int(probability)))

    if probability <= 40:
        risk_level = "Safe"
    elif probability <= 70:
        risk_level = "Suspicious"
    else:
        risk_level = "High Risk"
        
    highlight_words = extract_highlight_words(message)
    tips = get_prevention_tips(fraud_type)
    
    return {
        "fraud_type": fraud_type,
        "scam_probability": probability,
        "risk_level": risk_level,
        "highlight_words": highlight_words,
        "prevention_tips": tips
    }
