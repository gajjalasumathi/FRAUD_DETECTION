from flask import Blueprint, request, jsonify
from services.ml_service import predict_fraud
from database.db import save_analysis
import traceback

analyze_bp = Blueprint('analyze', __name__)

@analyze_bp.route('/analyze', methods=['POST'])
def analyze_message():
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({"error": "Invalid request. 'message' field is required."}), 400
            
        message = data['message'].strip()
        if not message:
            return jsonify({"error": "Message cannot be empty."}), 400
            
        # Call ML service
        result = predict_fraud(message)
        
        # Save to DB asynchronously or synchronously based on needs
        save_analysis(
            message=message,
            fraud_type=result['fraud_type'],
            probability=result['scam_probability'],
            risk_level=result['risk_level']
        )
        
        return jsonify(result), 200
        
    except Exception as e:
        print(f"Error analyzing message: {traceback.format_exc()}")
        return jsonify({"error": "An internal error occurred during analysis."}), 500

@analyze_bp.route('/report', methods=['POST'])
def report_message():
    try:
        data = request.get_json()
        if not data or 'message' not in data or 'fraud_type' not in data:
            return jsonify({"error": "Fields 'message' and 'fraud_type' are required."}), 400
            
        message = data['message'].strip()
        fraud_type = data['fraud_type'].strip()
        
        from database.db import save_feedback
        success = save_feedback(message, fraud_type)
        if success:
            return jsonify({"status": "Successfully reported and saved for future training."}), 200
        else:
            return jsonify({"error": "Failed to save feedback."}), 500
    except Exception as e:
        print(f"Error saving reported message: {traceback.format_exc()}")
        return jsonify({"error": "An internal error occurred."}), 500
