import os
import json
from pymongo import MongoClient
from datetime import datetime

# Use local MongoDB or define MONGO_URI in env
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = "fraud_detection"
FALLBACK_FILE = os.path.join(os.path.dirname(__file__), "fallback_feedback.json")

client = None
db = None

def init_db(app=None):
    global client, db
    try:
        # Fast 2-second timeout so the API doesn't hang if Mongo isn't running
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
        client.admin.command('ping') # Test connection
        db = client[DB_NAME]
        print("Connected to MongoDB successfully.")
    except Exception as e:
        print(f"MongoDB not available, using local JSON fallback.")
        db = None

def _save_to_json(data):
    try:
        if os.path.exists(FALLBACK_FILE):
            with open(FALLBACK_FILE, 'r') as f:
                logs = json.load(f)
        else:
            logs = []
        logs.append(data)
        with open(FALLBACK_FILE, 'w') as f:
            json.dump(logs, f, indent=4)
    except Exception as e:
        print(f"Error saving to JSON fallback: {e}")

def save_analysis(message, fraud_type, probability, risk_level):
    if client is None:
        init_db()
        
    data = {
        "message": message,
        "fraud_type": fraud_type,
        "probability": probability,
        "risk_level": risk_level,
        "timestamp": datetime.utcnow().isoformat()
    }

    if db is not None:
        try:
            db.analysis_logs.insert_one(data.copy())
            return True
        except Exception as e:
            print(f"Error saving analysis to db: {e}")
            
    # Fallback
    _save_to_json(data)
    return True

def save_feedback(message, reported_type):
    if client is None:
        init_db()
        
    data = {
        "message": message,
        "label": reported_type,
        "timestamp": datetime.utcnow().isoformat()
    }

    if db is not None:
        try:
            db.user_feedback.insert_one(data.copy())
            return True
        except Exception as e:
            print(f"Error saving feedback to db: {e}")
            
    # Fallback
    _save_to_json(data)
    return True
