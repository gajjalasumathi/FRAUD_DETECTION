from flask import Flask, jsonify
from flask_cors import CORS
from database.db import init_db
from routes.analyze import analyze_bp
from services.ml_service import load_model
import os

app = Flask(__name__)
CORS(app) # Enable CORS for frontend integration

# App Configuration
app.config['JSON_SORT_KEYS'] = False # Keep response keys in order defined

# Register Blueprints
app.register_blueprint(analyze_bp)

@app.route('/', methods=['GET'])
def health_check():
    return jsonify({"status": "API is running"}), 200

def initialize_app():
    # Load model once at startup
    try:
        load_model()
        print("Scam Model Loaded Successfully.")
    except Exception as e:
        print(f"Error loading model: {e}")
        
    # Initialize Database connection
    init_db(app)

# Run initialization steps
initialize_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    # In production, use a WSGI server like gunicorn, e.g., gunicorn app:app
    app.run(host="0.0.0.0", port=port, debug=False)
